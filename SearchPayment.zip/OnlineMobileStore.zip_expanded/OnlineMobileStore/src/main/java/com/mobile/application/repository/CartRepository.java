package com.mobile.application.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mobile.application.model.Cart;
@Repository
public interface CartRepository extends CrudRepository<Cart, String> {

//	List<Cart> findAllById(String email);

	

}
