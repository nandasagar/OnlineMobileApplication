package com.mobile.application.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mobile.application.model.Item;
import com.mobile.application.model.User;
import com.mobile.application.repository.ItemRepository;
import com.mobile.application.repository.UserRepository;

@Service
@Transactional
public class UserService {
	
@Autowired
private  UserRepository userRepo;
	
@Autowired
private  ItemRepository ItemRepo ;


	public UserService(UserRepository userRepository) {
		this.userRepo=userRepository;
	}
	
	
	
	public void saveUser(User user ) {
		userRepo.save(user);
	}

	public User ValidateUser(User user) {
		
		User u=userRepo.findById(user.getEmail()).get();
		return u;
	}
	
	public List<User> FetchUser() {
	
		List<User> u=(List<User>) userRepo.findAll();
		return u;
	}


	
	
}
