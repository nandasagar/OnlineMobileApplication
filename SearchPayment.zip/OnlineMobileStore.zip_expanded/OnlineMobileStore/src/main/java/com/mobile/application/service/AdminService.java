package com.mobile.application.service;

public class AdminService {

}
