package com.mobile.application.controller;



import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.mobile.application.model.Cart;
import com.mobile.application.model.Orders;
import com.mobile.application.repository.OrdersRepository;
import com.mobile.application.service.OrdersService;


@Controller
@SessionAttributes("Orders")
public class OrdersController {

	@ModelAttribute("Orders")
	public Orders setUp()
	{
		return new Orders();
		
	}
	
	
	@Autowired
	private OrdersRepository orderRepository;
	private OrdersService orderService;
	
	
    @PostMapping(path="/save-order/{email}/{total}/{quantity}/{model}")
	   //To Store Orders value into session
    public ModelAndView order(
    		@ModelAttribute("Orders") Orders orders,
    		Cart c ,@PathVariable ("email")String email,
    		@PathVariable ("total")int total,@PathVariable ("quantity") int quantity,
    		@PathVariable ("model")int mode, Model model) {
    System.out.println("Before orders");
    orders.setModel(mode); 	
    orders.setEmail(email);	
	orders.setQuantity(quantity);
	orders.setTotal(total);
	orders.setAddress("IN");
	System.out.println(orders);
    Orders o=	orderRepository.save(orders);
    
    ModelAndView m=new  ModelAndView("payment");
    m.addObject("orders", o);
		return m;
   
    } 
    
    
    @RequestMapping("/myorder")
    
    public ModelAndView myOrder()
    {
    	System.out.println("Ba");
    	//List<Orders> o=(List<Orders>) orderRepository.findAll();
    	List<Orders> o=(List<Orders>) orderRepository.findAll();
    	System.out.println("Aa");
    	List<Orders> l=new ArrayList<>();
    
    	for (var i:o)
    	{
    		if(i.getEmail().equals("bb"))
    		{
    			l.add(i);
    		}
    		
    	}
    	ModelAndView m=new ModelAndView("displaypage");
    	m.addObject("list", l);
    	return m;
    }
    
    
    //working Fine
 // Show All Orders
 		@RequestMapping("/allorder")
 	    public String home(Model model) {
 			
 			System.out.println(this.getClass().getSimpleName() + ":=======>Showing Orders list.");
 			List<Orders> o=(List<Orders>) orderRepository.findAll();
 			model.addAttribute("list",o );
 	         return "allorder";
 	    }
 	    

    
	
}
