package com.mobile.application.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mobile.application.model.Cart;
import com.mobile.application.repository.CartRepository;

@Service
@Transactional

public class CartService {
	@Autowired
	private CartRepository cartRepo;

	public CartService(CartRepository cartRepo) {
	
		this.cartRepo = cartRepo;
	}
	
	public void saveCart(Cart cart ) {
		
		cartRepo.save(cart);
	}

	public Optional<Cart> getById(String email) {
		// TODO Auto-generated method stub
		return cartRepo.findById(email);
		
	}

	/*
	 * public List<Cart> listAll() { // TODO Auto-generated method stub return
	 * (List<Cart>) cartRepo.findAll(); }
	 */

	public void delete(String email) {
		cartRepo.deleteById(email);
	}
	
}
