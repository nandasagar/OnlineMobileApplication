package com.mobile.application.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.mobile.application.model.User;

@Repository
public interface UserRepository extends CrudRepository<User, String> {
	//public User findByUsernameAndPassword(String username, String password);

}
