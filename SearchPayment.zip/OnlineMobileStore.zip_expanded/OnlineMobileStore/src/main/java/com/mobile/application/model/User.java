package com.mobile.application.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="user")
public class User
{
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	@Column(name="id")
	private int id;
	
	@Column(name="email", nullable=false)
	private String email;
	
	@Column(name="name", nullable=false)
	private String name;
	
	@Column(name="phonenumber", nullable=false)
	private String phonenumber;
	
	@Column(name="password", nullable=false)
	private String password;
	
	@Column(name="roleid", nullable=false)
	private int roleid;

	
	public User() {
		super();
	}

	public User(String email, String name, String phonenumber, String password, int roleid) {
		super();
		this.email = email;
		this.name = name;
		this.phonenumber = phonenumber;
		this.password = password;
		this.roleid = roleid;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getRoleid() {
		return roleid;
	}

	public void setRoleid(int roleid) {
		this.roleid = roleid;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", email=" + email + ", name=" + name + ", phonenumber=" + phonenumber + ", password="
				+ password + ", roleid=" + roleid + "]";
	}
	
	/*
	 * 
	 * @OneToMany(targetEntity =Orders.class,cascade=CascadeType.ALL)
	 * 
	 * @JoinColumn(name="ou_fk",referencedColumnName = "email" ) private
	 * List<Orders> orderss;
	 * 
	 * 
	 */
	
	
	
	
	
}
	