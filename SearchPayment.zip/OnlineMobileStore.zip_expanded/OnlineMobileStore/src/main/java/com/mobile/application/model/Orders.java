package com.mobile.application.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="orders")

public class Orders {

	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	@Column(name="orderid")
	private int orderid;
	
	
	@Column(name="email")
	private String email;
	
	@Column(name="address")
	private String address;
	
	@Column(name="model")
	private int model;
	
	@Column(name="quantity")
	private int quantity;
	
	@Column(name="total")
	private int total;

	 
	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getModel() {
		return model;
	}

	public void setModel(int model) {
		this.model = model;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public Orders(String email, String address, int model, int quantity, int total) {
		super();
		this.email = email;
		this.address = address;
		this.model = model;
		this.quantity = quantity;
		this.total = total;
	}

	public Orders() {
		super();
	}

	@Override
	public String toString() {
		return "Orders [orderid=" + orderid + ", email=" + email + ", address=" + address + ", model=" + model
				+ ", quantity=" + quantity + ", total=" + total + "]";
	}
	
		
}
