package com.mobile.application.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.servlet.ModelAndView;

import com.mobile.application.model.Orders;
import com.mobile.application.model.Payment;
import com.mobile.application.repository.PaymentRepository;

@Controller
@RequestMapping("/Orders")
public class PaymentController {
	
	
	
	
	@Autowired
	private PaymentRepository paymentRepository;
	
    
//payment   /{orderid}{email}/{total}     @PathVariable ("orderid") int oid, @PathVariable ("email")String email, @PathVariable ("total")int total
	    
        @PostMapping(path="/save-payment")
		public ModelAndView savePay(Payment payment,
				@SessionAttribute("Orders")Orders orders) {
		
        	System.out.println(orders);			
			  int oid =orders.getOrderid();
			  int tot =orders.getTotal(); 
			  int mod=orders.getModel(); 
			  String email=orders.getEmail(); 
			  System.out.println(mod);
			 
        	payment.setOrderid(oid);
        	payment.setEmail(email);
        	payment.setTotal(tot);

        Payment u=	paymentRepository.save(payment);
	    ModelAndView m=new  ModelAndView("successpage")	;
	    m.addObject("l", u);
			return m;
		}
	    

}
