package com.mobile.application.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import com.mobile.application.model.Cart;
import com.mobile.application.model.Orders;
import com.mobile.application.model.Payment;
import com.mobile.application.model.User;
import com.mobile.application.repository.CartRepository;
import com.mobile.application.repository.OrdersRepository;
import com.mobile.application.repository.PaymentRepository;
import com.mobile.application.repository.UserRepository;
import com.mobile.application.service.CartService;
import com.mobile.application.service.OrdersService;
import com.mobile.application.service.PaymentService;
import com.mobile.application.service.UserService;
//import com.mobile.application.service.UserService;

@Controller
//@RequestMapping(path="/home")
	public class ApplicationController {
	 
	@Autowired
	private UserRepository userRepository; 
	private UserService userService;
	
	@Autowired
	private CartRepository cartRepository;
	private CartService cartService;
	
	
	
	@Autowired
	private PaymentRepository paymentRepository;
	//private PaymentService  paymentService;
	
	    @RequestMapping("/home")
	    public String home() {
	   
	        return "home";
	    }
	    
	    
	    @RequestMapping("/login")
	    public String login() {
	   
	        return "login";
	    }
	    
	    @RequestMapping("/register")
	    public String register() {
	   
	        return "register";
	    }
	    
	    @RequestMapping("/welcome")
	    public String welcome() {
	   
	        return "welcome";
	    }
	    @RequestMapping("/admin")
	    public String admin() {
	   
	        return "admin";
	    }
	    @RequestMapping("/logout")
	    public String logut() {
	   
	        return "home";
	    }
	    
	    
		//Login	  ,BindingResult bindingResult
	    @PostMapping(path="/validateuser")
		public ModelAndView ValidateUser(@ModelAttribute User user) {
	    	
	    	String log="welcome";
	    	
	    	if(user.getEmail()=="n" && user.getPassword()=="n")
    		{
    			log="welcome";
    		}
    			/*	List<User> l=userService.FetchUser();
	    	String log="login";
	    	for(var l1:l)
	    	{
	    		if(l1.getEmail()==user.getEmail())
	    		if(l1.getEmail()=="n" && l1.getPassword()=="n")
	    		{
	    			log="home";
					
					 * User u=userService.ValidateUser(user); if((u.getEmail()==user.getEmail())&&
					 * u.getPassword()==user.getPassword()&& u.getRoleid()==1 ) { log="home"; } else
					 * if((u.getEmail()==user.getEmail())&& u.getPassword()==user.getPassword()&&
					 * u.getRoleid()==2) { log="home"; } else log="login";
					 	    		}*/
	    	
		    ModelAndView m=new  ModelAndView(log)	;
		    m.addObject("message ", "Invallid");
			return m;
	    }
	   	
		/*
		  public Cart give() { Cart c= new Cart("nanda@",1001,2); return c; }
		 */
	    
	    
	    @RequestMapping(path="/cart")
	    
	    public String cart()
	    {
	    	return "cart";
	    }
	    
	    //cart
	    	    
	    @PostMapping(path="/save-cart")
	    
		public ModelAndView saveCart(Cart cart) {
	    	  	
	    	int t=(int) (cart.getPrice() * cart.getQuantity());
			cart.setTotal(t);	
	    Cart c=	cartRepository.save(cart);
	    
	   
	     ModelAndView m=new  ModelAndView("orders");
	     m.addObject("l", c);
	     return m;
			/*
			 * String e=cart.getEmail(); m.addObject("cart", cartService.getById(e));
			 * 
			 * ModelAndView m=new ModelAndView("orders");
			 * return m;
			 */	
	    }

	
	    @PostMapping("/delete/{email}")
	    public String deletestudent(@PathVariable(name = "email") String email) {
	        cartService.delete(email);
	        return "allorders";
	    }
	    
	    
	    
	    //orders
		/* 
	    @PostMapping(path="/save-order/{email}/{total}/{quantity}")
	   
	    public ModelAndView order(Orders order,Cart c ,@PathVariable ("email")String email,
	    		@PathVariable ("total")int total,@PathVariable ("quantity") int quantity) {
	    order.setEmail(email);	
		order.setQuantity(quantity);
		order.setTotal(total);
		order.setAddress("IN");
		System.out.println(order);
	    Orders o=	orderRepository.save(order);
	    ModelAndView m=new  ModelAndView("payment");
	    m.addObject("orders", o);
			return m;
	    } 
	    
	    //working Fine
	    
	 // Show All Orders
		@RequestMapping("/allorder")
	    public String home(Model model) {
			System.out.println(this.getClass().getSimpleName() + ":=======>Showing Orders list.");
	         model.addAttribute("allorder", orderService.getAllOrders());
	         return "allorder";
	    }
	    
	    */	    	    
	    
	    
	    
	  //dummy payment
	   

	    @RequestMapping(path="/dummyp")
	    
	    public String dummy()
	    {
	    	return "dummyp";
	    }
		
	   //ends 
 
	    
	    
	    
	    //payment
			/*
			 
			@PostMapping( path="/save-payment/{orderid}/{email}/{total}")
			  public ModelAndView paymentSave(Payment payment ,@PathVariable ("orderid")int orderid,
			    		@PathVariable ("email")String email,
			    		@PathVariable ("total")int total) {
			    	
			    	payment.setOrderid(orderid);
			    	payment.setEmail(email);	
			    	payment.setTotal(total);
			    	System.out.println(payment);
			    	Payment p=	paymentRepository.save(payment);
				
			    ModelAndView m=new  ModelAndView("pdone");
			    m.addObject("payment", p);
					return m;
			    }  
	    */
	    
	   	    
	//Registration	
			@PostMapping(path="/save-user")
			public ModelAndView registerUser(User user) {
			User u=	userRepository.save(user);
		    ModelAndView m=new  ModelAndView("welcome")	;
		    m.addObject("l", u);
				return m;
				
			
		}
		
	    
	    
	    
	    
	    
	    
	    
	}