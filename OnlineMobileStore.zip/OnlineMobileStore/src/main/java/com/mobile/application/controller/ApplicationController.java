package com.mobile.application.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.ModelAndViewDefiningException;

import com.mobile.application.model.User;
import com.mobile.application.repository.UserRepository;
//import com.mobile.application.service.UserService;

@Controller
//@RequestMapping(path="/home")
	public class ApplicationController {
	 
	@Autowired
	private UserRepository userRepository; 
	//UserService userService;
	
	
	    @RequestMapping("/home")
	    public String home() {
	   
	        return "home";
	    }
	    
	    
	    @RequestMapping("/login")
	    public String login() {
	   
	        return "login";
	    }
	    
	    @RequestMapping("/register")
	    public String register() {
	   
	        return "register";
	    }
	  
	    @PostMapping(path="/validateuser")
		public ModelAndView ValidateUser(@ModelAttribute User user,BindingResult bindingResult) {
		User u=	userRepository.save(user);
	    ModelAndView m=new  ModelAndView("successpage")	;
	    m.addObject("l", u);
			return m;
			
			
			@PostMapping(path="/save-user")
			public ModelAndView registerUser(User user) {
			User u=	userRepository.save(user);
		    ModelAndView m=new  ModelAndView("successpage")	;
		    m.addObject("l", u);
				return m;
				
		}
		
	    
	    
	    
	    
	    
	    
	    
	}